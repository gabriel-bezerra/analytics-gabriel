library(plyr)
library(ggplot2)

theme_set(theme_bw())

ci = function(x, alpha = 0.05) {
    q = 1 - alpha/2
    s = sd(x)
    xbar = mean(x)
    n = length(x)
    if (n >= 30)
        error = qnorm(q)*s/sqrt(n)
    else
        error = qt(q, df = n-1)*s/sqrt(n)

    lower = xbar-error
    upper = xbar+error
    return(data.frame(lower, upper, y=xbar))
}

ci.prop = function(m, n, alpha = 0.05) {
    p = m/n
    q = 1 - alpha/2

    if (n*p >= 10)
        error = qnorm(q)*sqrt(p*(1-p)/n)
    else
        error = qbinom(q, n, p)*sqrt(p*(1-p)/n)

    lower = p-error
    upper = p+error
    return(data.frame(lower, upper, y=p))
}

plot.ci = function(df.ci, groups, var, file, ylim.vals=c(min(df.ci$lower),max(df.ci$upper))) {
    png(file, width=800, height=600)
    print(ggplot(df.ci, aes_string(x=groups)) + geom_point(aes(y=y)) + geom_errorbar(aes(ymax=upper, ymin=lower)) + ylab(var) + ylim(ylim.vals))
    dev.off()
}

calc.group.ci = function(df, groups, var, alpha=.05, prop.ci=F, n) {
    if (prop.ci)
        ddply(df, groups, function(df) ci.prop(mean(df[,var]), n, alpha))
    else
        ddply(df, groups, function(df) ci(df[,var], alpha))
}
