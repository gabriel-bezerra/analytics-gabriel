source('gabarito-lab04-common.R')

dados.dep.ano = read.csv('dados-deputados.csv')

groups = "estado"
var = "gastos.total"

dep.gastos.estado.alpha10 = calc.group.ci(dados.dep.ano, groups, var, alpha=.1)
plot.ci(dep.gastos.estado.alpha10, groups, var, "dep-gastos-estado-alpha10.png")
