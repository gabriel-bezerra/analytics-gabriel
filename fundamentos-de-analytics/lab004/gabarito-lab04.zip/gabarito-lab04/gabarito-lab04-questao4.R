source('gabarito-lab04-common.R')

dados.dep.ano = read.csv('dados-deputados.csv')

groups = "estado"
var = "presencas.total"

dep.prop.presencas.estado = calc.group.ci(dados.dep.ano, groups, var, .10, prop.ci=T, n=202)

plot.ci(dep.prop.presencas.estado, groups, "prop.presencas", "dep-prop-presencas-estado-alpha10.png")
