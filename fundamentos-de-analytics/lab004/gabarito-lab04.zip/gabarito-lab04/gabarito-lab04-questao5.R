source('gabarito-lab04-common.R')

dados.dep = read.csv('dados-deputados.csv')

presencas.estado = aggregate(presencas.total ~ estado, dados.dep, mean)

estado.a = presencas.estado[which.max(presencas.estado$presencas.total), "estado"]
estado.b = presencas.estado[which.min(presencas.estado$presencas.total), "estado"]

presencas.deps.a = subset(dados.dep, estado == estado.a)
presencas.deps.b = subset(dados.dep, estado == estado.b)

dep.menos.estado.a = presencas.deps.a[which.min(presencas.deps.a$presencas.total),]
dep.mais.estado.b = presencas.deps.b[which.max(presencas.deps.b$presencas.total),]

print(cbind(ci.prop(dep.menos.estado.a$presencas.total, 202, .05), estado.a))
print(cbind(ci.prop(dep.mais.estado.b$presencas.total, 202, .05), estado.b))
