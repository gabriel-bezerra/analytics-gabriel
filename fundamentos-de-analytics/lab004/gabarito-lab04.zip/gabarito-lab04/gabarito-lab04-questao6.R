source('gabarito-lab04-common.R')

dados.dep = read.csv('dados-deputados.csv')

gastos.estado = aggregate(gastos.total ~ estado, dados.dep, mean)

estado.a = gastos.estado[which.max(gastos.estado$gastos.total), "estado"]
estado.b = gastos.estado[which.min(gastos.estado$gastos.total), "estado"]

gastos.deps.a = subset(dados.dep, estado == estado.a)
gastos.deps.b = subset(dados.dep, estado == estado.b)

dep.menos.estado.a = gastos.deps.a[which.min(gastos.deps.a$gastos.total),]
dep.mais.estado.b = gastos.deps.b[which.max(gastos.deps.b$gastos.total),]

print(data.frame(gastos.total=mean(dep.menos.estado.a$gastos.total), estado.a))
print(data.frame(gastos.total=mean(dep.mais.estado.b$gastos.total), estado.b))
