source('gabarito-lab04-common.R')

dados.dep.ano = read.csv('dados-deputados.csv')

groups = "regiao"
var = "gastos.total"

dep.gastos.regiao.alpha05 = calc.group.ci(dados.dep.ano, groups, var, alpha=.05)
dep.gastos.regiao.alpha25 = calc.group.ci(dados.dep.ano, groups, var, alpha=.25)

ymin=min(c(dep.gastos.regiao.alpha05$lower, dep.gastos.regiao.alpha25$lower))
ymax=max(c(dep.gastos.regiao.alpha05$upper, dep.gastos.regiao.alpha25$upper))

plot.ci(dep.gastos.regiao.alpha05, groups, var, "dep-gastos-regiao-alpha05.png", c(ymin, ymax))
plot.ci(dep.gastos.regiao.alpha25, groups, var, "dep-gastos-regiao-alpha25.png", c(ymin, ymax))

groups = "regiao"
var = "presencas.total"

dep.prop.presencas.regiao.alpha05 = calc.group.ci(dados.dep.ano, groups, var, .05, prop.ci=T, n=202)
dep.prop.presencas.regiao.alpha25 = calc.group.ci(dados.dep.ano, groups, var, .25, prop.ci=T, n=202)

ymin=min(c(dep.prop.presencas.regiao.alpha05$lower, dep.prop.presencas.regiao.alpha25$lower))
ymax=max(c(dep.prop.presencas.regiao.alpha05$upper, dep.prop.presencas.regiao.alpha25$upper))

plot.ci(dep.prop.presencas.regiao.alpha05, groups, "prop.presencas", "dep-prop-presencas-regiao-alpha05.png", c(ymin, ymax))
plot.ci(dep.prop.presencas.regiao.alpha25, groups, "prop.presencas", "dep-prop-presencas-regiao-alpha25.png", c(ymin, ymax))
