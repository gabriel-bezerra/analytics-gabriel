# Escreva um script R que gera os gráficos FDA, FDP e as qqnorms dos seguintes dados: (i)
# intervalos em que as máquinas estiveram ocupadas; (ii) intervalos em que as máquinas 
# estiveram ociosas; (iii) intervalos em que as máquinas estiveram ociosas separados por
# laboratório. Nos gráficos FDPs, plote duas linhas, uma com a densidade dos dados obtidos 
# na base de dados e outra com a densidade de uma distribuição normal gerada com a média e 
# o desvio padrão dos dados obtidos da base de dados. Para cada item solicitado deve ser 
# gerada uma figura no formato *.png, portanto, ao todo devem ser geradas 3 figuras.

args = commandArgs(TRUE)
df = read.table(args[1], header = T)

#Separa os dados dos intervalos de máquinas ociosas e de máquinas ocupadas
df.ociosa <- subset(df, df$ociosa=='TRUE')
df.ocupada <- subset(df, df$ociosa=='FALSE')

normDensity <- function(data.sample){
    density(rnorm(length(data.sample), mean = mean(data.sample), sd = sd(data.sample)))
}

gera.graficos <-function(dados, mainLabel, plotlegend){
    plot(density(dados), main=paste("FDP", mainLabel, sep=" "), xlab= "Intervalos", ylab= "Densidade")
    lines(normDensity(dados), col="red",lwd=2)
    if(plotlegend){
        legend("topright", c("dados","normal = mean(dados) e sd(dados)"), fill=c("black","red"))
    }
    plot(ecdf(dados), main=paste("FDA", mainLabel, sep=" "), verticals = TRUE, do.points=FALSE, xlab= "Intervalos", ylab= "Fn(intervalos)")
    qqnorm(dados, main=paste("qq-norm", mainLabel, sep=" "), xlab= "Theoretical Quantiles", ylab= "Sample Quantile")
    qqline(dados)
}

#gera os graficos do item (i)
png("resposta-questao1-i.png")
par(mfrow=c(3,1))
gera.graficos(df.ocupada$intervalo, mainLabel="Ocupada", TRUE)
dev.off()

#gera os gráficos do item (ii)
png("resposta-questao1-ii.png")
par(mfrow=c(3,1), las =1)
gera.graficos(df.ociosa$intervalo, mainLabel="Ociosa", TRUE)
dev.off()

#gera os gráficos do item (iii)
#-obtém  os níveis dos laboratórios
laboratorios.ids = levels(df.ociosa$laboratorio)

png("resposta-questao1-iii.png")
par(mfrow=c(length(laboratorios.ids),3), las=1)
for(lab in laboratorios.ids) {
    dados = subset(df.ociosa$intervalo, df.ociosa$laboratorio == lab)
    gera.graficos(dados,lab, FALSE)
}
dev.off()
