# Escreva um script R que calcula o  Zskewness e o  Zkurtosis  dos 
# seguintes dados:  (i) intervalos em que as máquinas estiveram ocupadas;
# (ii) intervalos em que as máquinas estiveram ociosas; (iii) intervalos 
# em que as máquinas estiveram ociosas separados por laboratório. Os 
# resultados dos três itens devem ser salvos como uma tabela um único 
# arquivo no formato *.txt. A tabela deve ter 3 colunas: cenário, Zskewness e  Zkurtosis .
library(moments)

args = commandArgs(TRUE)
df = read.table(args[1], header = T)

#Separa os dados dos intervalos de máquinas ociosas e de máquinas ocupadas
df.ociosa <- subset(df, df$ociosa=='TRUE')
df.ocupada <- subset(df, df$ociosa=='FALSE')

#Calcula o Zkurtosis e o Zskewness e salva os resultados em um arquivo
ZkurtosisAndZskewness <- function(scenario, sample.data, fileConn){
	k <- kurtosis(sample.data)/sqrt(24/length(sample.data))
        s <- skewness(sample.data)/sqrt(6/length(sample.data))
	ln <- paste (scenario,  k, s, sep = "\t")
	writeLines(ln, fileConn)
}

fileConn<-file("resposta-questao2.txt","w")
writeLines("cenario\tZkurtosis\tZskewness", fileConn)

#Soluciona o item (i) e salva no arquivo
ZkurtosisAndZskewness("Ocupada",df.ocupada$intervalo,fileConn)

#Soluciona o item (ii) e salva no arquivo
ZkurtosisAndZskewness("Ociosa",df.ociosa$intervalo,fileConn)

#Soluciona o item (iii) e salva no arquivo
laboratorios.ids = levels(df.ociosa$laboratorio)
for(lab in laboratorios.ids) {
    data = subset(df.ociosa$intervalo, df.ociosa$laboratorio == lab)
    ZkurtosisAndZskewness(lab,data,fileConn)
}
close(fileConn)
