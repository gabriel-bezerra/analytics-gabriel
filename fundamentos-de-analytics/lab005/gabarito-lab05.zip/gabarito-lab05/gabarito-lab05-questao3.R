# Escreva um script R que aplica os testes Anderson-Darling e 
# Shapiro-Wilk sobre os seguintes dados: (i) intervalos em que
# as máquinas estiveram ocupadas; (ii) intervalos em que as
# máquinas estiveram ociosas; (iii) intervalos em que as máquinas
# estiveram ociosas separados por laboratório. Você deve salvar 
# os resultados em um único arquivo com uma tabela com  quatro 
# colunas: nome do teste, cenário, valor da estatística (A ou W) e
# o valor do p-value.

library(nortest)
library(moments)

args = commandArgs(TRUE)
df = read.table(args[1], header = T)

#Separa os dados dos intervalos de máquinas ociosas e de máquinas ocupadas
df.ociosa <- subset(df, df$ociosa=='TRUE')
df.ocupada <- subset(df, df$ociosa=='FALSE')

executaTestes <- function(scenario, data, fileConn){
    ln <- paste(scenario, "ad", ad.test(data)$p.value,ad.test(data)$statistic,sep = "\t")
    writeLines(ln, fileConn)
    ln <- paste(scenario, "shapiro",shapiro.test(data)$p.value,shapiro.test(data)$statistic, sep = "\t")
    writeLines(ln, fileConn)
}

fileConn<-file("resposta-questao3.txt","w")
writeLines("cenario\ttest\tpvalue\tstatistic", fileConn)

#Soluciona o item (i) e salva no arquivo
executaTestes("ocupada",df.ocupada$intervalo,fileConn)

#Soluciona o item (ii) e salva no arquivo
executaTestes("Ociosa",df.ociosa$intervalo,fileConn)

#Soluciona o item (iii) e salva no arquivo
laboratorios.ids = levels(df.ociosa$laboratorio)
for(lab in laboratorios.ids) {
    data = subset(df.ociosa$intervalo, df.ociosa$laboratorio == lab)
    executaTestes(lab,df.ociosa$intervalo,fileConn)
}
close(fileConn)
