# Considerando os totais de tempo em que cada máquina permaneceu 
# ociosa e os totais de tempo em que cada máquina permaneceu ocupada, 
# implemente uma solução em R que permite utilizar os testes 
# Anderson-Darling e Shapiro-Wilk para verificar se os tempos em 
# que as máquinas permaneceram nesses estados seguem uma distribuição
# normal, antes e após uma transformação com sqrt e log.

library(nortest)
args = commandArgs(TRUE)
df = read.table(args[1], header = T)

executaTestes <- function (scenario, msample){
    print(paste(scenario,"AD",ad.test(msample)$p.value,ad.test(msample)$statistic,sep=" "))
    print(paste(scenario,"SW",shapiro.test(msample)$p.value,shapiro.test(msample)$statistic,sep=" "))
}

#Separa os dados dos intervalos de máquinas ociosas e de máquinas ocupadas
df.ociosa <- subset(df, df$ociosa=='TRUE')
df.ocupada <- subset(df, df$ociosa=='FALSE')

#Soma os intervalos de cada máquina
new.ociosa <- aggregate(df.ociosa$intervalo, by=list(maquina=df.ociosa$maquina),FUN=sum)
new.ocupada <- aggregate(df.ocupada$intervalo, by=list(maquina=df.ocupada$maquina),FUN=sum)

paste("scenario","teste", "p-valor", "estatistica")
executaTestes("ociosa", new.ociosa$x)
executaTestes("ocupada", new.ocupada$x)
executaTestes("log(ociosa)", log(new.ociosa$x))
executaTestes("log(ocupada)", log(new.ocupada$x))
executaTestes("sqrt(ociosa)", sqrt(new.ociosa$x))
executaTestes("sqrt(ocupada)", sqrt(new.ocupada$x))
