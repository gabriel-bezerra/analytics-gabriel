### Libs
require(plyr)
require(ggplot2)

### Funções

calcula.estatisticas = function(df, col.valores) {
    x = df[,col.valores]
    return(data.frame(Media=mean(x),
                    Mediana=median(x),
                    Minimo=min(x),
                    Maximo=max(x),
                    Quartil.1=quantile(x, .25),
                    Quartil.3=quantile(x, .75),
                    Percentil.5=quantile(x, .05),
                    Percentil.95=quantile(x, .95),
                    Desvio.Padrao=sd(x),
                    IQR=IQR(x)))
}

calcula.proporcao.ocupada = function(df) {
    tempo.ocupada = sum(df[df$ociosa == F, "intervalo"])
    tempo.ociosa = sum(df[df$ociosa == T, "intervalo"])
    tempo.total = tempo.ocupada + tempo.ociosa
    proporcao.ocupada = tempo.ocupada / tempo.total
    return(data.frame(tempo.ocupada, tempo.total, proporcao.ocupada))
} 

calcula.media.proporcao.ocupada = function(df) {
    media.proporcao.ocupada = sum(df$tempo.ocupada)/sum(df$tempo.total)
    return(data.frame(media.proporcao.ocupada)) 
}

plota.graficos = function(df, col.valores, col.agrupamento, data.id) {
    png(paste("q1_histograma_", data.id, ".png", sep=""), width=800, height=600)
    print(ggplot(df, aes_string(x=col.valores)) + geom_histogram(aes(y=..density..)) 
                    + facet_wrap(as.formula(paste("~", col.agrupamento))))
    dev.off()
    
    # Outra alternativa de visualização dos dados, usando escala de
    # log na base 10 no eixo-x, útil para distribuições cauda longa      
    png(paste("q1_histograma-log10_", data.id, ".png", sep=""), width=800, height=600)
    print(ggplot(df, aes_string(x=col.valores)) + geom_histogram(aes(y=..density..)) 
                    + scale_x_log10() + facet_wrap(as.formula(paste("~", col.agrupamento))))
    dev.off()
    
    png(paste("q1_boxplot_", data.id, ".png", sep=""), width=800, height=600)
    print(ggplot(df, aes_string(x=col.agrupamento, y=col.valores)) + geom_boxplot() + coord_flip()) 
    dev.off() 
}

gera.resultados = function(dados, estatisticas, col.valores, col.agrupamento, data.id) {
    write.table(estatisticas, paste("q1_estatisticas_", data.id, ".txt", sep=""), row.names=F, quote=F)
    plota.graficos(dados, col.valores, col.agrupamento, data.id) 
}

### Main

theme_set(theme_bw())
df = read.table('atividade-maquinas-dsc.txt', header = T)

intervalos.ociosa = subset(df, ociosa == T)
intervalos.ocupada = subset(df, ociosa == F)
proporcao.ocupada = ddply(df, .(maquina, laboratorio), calcula.proporcao.ocupada)
mudancas.estado = ddply(df, .(maquina, laboratorio), nrow)
colnames(mudancas.estado) = c("maquina", "laboratorio", "mudancas.estado")

intervalos.ociosa.stats.labs = ddply(intervalos.ociosa, .(laboratorio), calcula.estatisticas, 
                                     col.valores="intervalo") 
gera.resultados(intervalos.ociosa, intervalos.ociosa.stats.labs, col.valores="intervalo", 
                col.agrupamento="laboratorio", data.id="intervalos-ociosa")

intervalos.ocupada.stats.labs = ddply(intervalos.ocupada, .(laboratorio), calcula.estatisticas, 
                                      col.valores="intervalo") 
gera.resultados(intervalos.ocupada, intervalos.ocupada.stats.labs, col.valores="intervalo", 
                col.agrupamento="laboratorio", data.id="intervalos-ocupada")

prop.ocupada.stats.labs = ddply(proporcao.ocupada, .(laboratorio), calcula.estatisticas, 
                                col.valores="proporcao.ocupada")
prop.ocupada.stats.labs$Media = ddply(proporcao.ocupada, .(laboratorio), 
                                      calcula.media.proporcao.ocupada)$media.proporcao.ocupada
gera.resultados(proporcao.ocupada, prop.ocupada.stats.labs, col.valores="proporcao.ocupada", 
                col.agrupamento="laboratorio", data.id="proporcao-ocupada")

mudancas.estado.stats.labs = ddply(mudancas.estado, .(laboratorio), calcula.estatisticas, 
                                   col.valores="mudancas.estado")
gera.resultados(mudancas.estado, mudancas.estado.stats.labs, col.valores="mudancas.estado", 
                col.agrupamento="laboratorio", data.id="mudancas-estado")

