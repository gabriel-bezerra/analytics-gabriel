# Re-executando questão 1 para reusar dados e funções
suppressMessages(source('gabarito-lab02-questao1.R'))

maquinas.ranking = proporcao.ocupada[order(proporcao.ocupada$proporcao.ocupada, decreasing=T),]

# Removendo a máquina que ficou mais de 80% do tempo ocupada, que considero um outlier por
# possuir um valor fora dos padrões de uso de uma máquina, possuindo um uso consideravelmente 
# maior do que todas as outras máquinas medidas, podendo ter sido ocasionado por erro
# nas medições.

maquinas.ranking = subset(maquinas.ranking, proporcao.ocupada < .8)
maquinas.top10 = head(maquinas.ranking, 10)

write.table(maquinas.top10[,c("maquina","laboratorio","proporcao.ocupada")], 
            "q2_proporcao-ocupada_top10.txt", quote=F, row.names=F)