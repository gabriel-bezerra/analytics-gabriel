# Programa FRH-Analytics UFCG-HP
# Lab3, exercicio 1
#
# Escreva um script R que gera o gráfico da Função de Distribuição Acumulada (FDA), 
# da Função de Densidade de Probabilidade (FDP), para variáveis contínuas, e da Função
# de Massa de Probabilidade (FMP), para variáveis discretas. Os dados que devem ser 
# utilizados para gerar os gráficos são: reputation, views, up_votes e down_votes.
# Apenas para melhorar a visualização dos dados, limite o eixo x dos gráficos entre 0
# e o valor do 99 percentil. Devem ser  geradas duas figuras no formato *.png: uma 
# figura contendo os gráficos FDP e/ou FDM e outra figura contendo os gráficos FDA.
# Cada gráfico deve ser devidamente identificado com o nome da variável aleatória a que se refere. 


df <- read.table("askubuntu.csv", head=T, sep= ",")

png("questao1-FDA.png")
par(mfrow=c(2,2))
plot(ecdf(df$reputation), verticals = FALSE, do.points = TRUE, xlim = c(0, quantile(df$reputation, 0.99)), las=1, main="Reputation")
plot(ecdf(df$views), verticals = FALSE, do.points = TRUE, xlim = c(0, quantile(df$views, 0.99)), las = 1, main = "Wiews")
plot(ecdf(df$up_votes), verticals = FALSE, do.points = TRUE, xlim = c(0, quantile(df$up_votes, 0.99)), las = 1, main = "Up Votes")
plot(ecdf(df$down_votes), verticals = FALSE, do.points = TRUE, xlim = c(0, quantile(df$down_votes, 0.99)), las = 1, main = "Down votes")
dev.off()

length(subset(df, reputation <= quantile(df$reputation, 0.99, names = FALSE))$reputation)

png("questao1-FMP.png")
par(mfrow=c(2,2))
plot(prop.table(table(df$reputation)), type = "h", ylab = "Densidade", xlim=c(0,quantile(df$reputation, 0.99)), las=1, main="Reputation")
plot(prop.table(table(df$views)), type = "h", ylab = "Densidade", xlim = c(0, quantile(df$views, 0.99)), las=1, main="Wiews")
plot(prop.table(table(df$up_votes)), type = "h", ylab = "Densidade", xlim = c(0, quantile(df$up_votes, 0.99)), las=1, main="Up Votes")
plot(prop.table(table(df$down_votes)), type = "h", ylab = "Densidade" ,xlim = c(0, quantile(df$down_votes, 0.99)), las=1, main="Down votes")
dev.off()
