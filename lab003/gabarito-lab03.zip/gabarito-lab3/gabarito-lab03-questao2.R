# Programa FRH-Analytics UFCG-HP
# Lab3, exercicio 2
#
# Escreva um script R que classifica os usuários segundo o número de visualizações do perfil.
# Para isso, gere uma nova coluna com a classe do usuário. Classifique as visualizações do 
# perfil do usuário em “Muito baixo”, “Baixo”, “Alto” e “Muito Alto”, utilizando os quartis 
# 0.25, 0.5 e 0.75. Por exemplo, se o número de visualizações de um usuário for menor ou igual
# ao valor do 0.25 quartil o atributo (coluna) “classe” desse usuário deve receber o valor
# “Muito Baixo”. Após isso, o script deve gerar uma figura em formato *.png contendo a FDA e 
# abaixo dela o histograma gerados com os dados da coluna classe.


df <- read.table("askubuntu.csv", head = T, sep = ",")

classifyUser <- function(view){
 	if(view <= q25){
		1 #"Muito Baixo"
	}else if(view <= q50){
		2 #"Baixo"
	}else if(view <= q75){
		3 #"Alto"
	}else{
		4 #"Muito Alto"
	}
}

levels = c("Muito Baixo","Baixo","Alto","Muito Alto")

q25 <- quantile(df$views, 0.25, names = FALSE)
q50 <- quantile(df$views, 0.50, names = FALSE)
q75 <- quantile(df$views, 0.75, names = FALSE)

df$class <- Vectorize(classifyUser)(df$views)

png("questao2-FDA-Histograma.png")
par(mfrow = c(2,1))

plot(ecdf(df$class), do.points = TRUE, las = 1, main = "FDA", xlim = c(1,4), axes = FALSE, xlab = "Nível de visualização do perfil")
axis(1, 1:4, levels)
axis(2, las = 1)

hist(df$class, las=1, main="Histograma", xlim = c(1,4), axes = FALSE, xlab = "Nível de visualização do perfil")
axis(1, 1:4, levels)
axis(2, las = 1, ylab="Frequência")
dev.off()
