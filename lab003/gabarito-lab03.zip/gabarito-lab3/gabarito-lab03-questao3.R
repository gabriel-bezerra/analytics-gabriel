# Programa FRH-Analytics UFCG-HP
# Lab3, exercicio 4
#
# Implemente um script R que gera a distribuição de probabilidades empirica dos dados da
# coluna reputation. O script também deve extrair dessa distribuição uma amostra contendo 
# a reputação de 25.000 usuários e salvá-la em um arquivo no formato *.txt, com cada usuário
# em uma linha do arquivo. Para permitir a análise dos dados, o script também deve: (i) gerar
# uma figura em formato *.png contendo um único gráfico FDA com os dados brutos e a amostra 
# gerada; (ii) imprimir os valores: min, max, média, mediana, 1º e 3º quartis. Dica: estude 
# com cuidado o help das funções sample, ecdf e hist no R. Essas funções podem tornar esse 
# exercício mais fácil.


soluction1 <- function(){
	sample(df$reputation, size = newSampleSize, replace = TRUE) 
}

soluction2 <- function(){
	vals <- get("x", environment(Fn))
	probs <- diff(c(0, get("y", environment(Fn))))
	sample(vals, newSampleSize, replace = TRUE, prob = probs)
}	

newSampleSize <- 25000

df <- read.table("askubuntu.csv", head = T, sep = ",")
Fn <- ecdf(df$reputation)
newSample <- soluction2()

summary(newSample)
summary(df$reputation)

df.mysample <- data.frame(seq(1, newSampleSize), newSample)
write.table(df.mysample, file="resultado-lab01-questao1.txt", row.names=F)

png("questao3-FDA.png")
plot(Fn, verticals= FALSE, do.points = TRUE, las = 1, main = "FDA Reputation", col = "blue")
lines(ecdf(newSample), verticals = FALSE, do.points = TRUE, col = "red", las = 1, main = "FDA Wiews")
legend("bottomright", c("Dados Brutos: 19.548 usuários", "Amostra gerada: 25.000 usuários"), fill=c("blue","red"))
dev.off()
