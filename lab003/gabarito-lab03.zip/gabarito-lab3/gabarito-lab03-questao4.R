# Programa FRH-Analytics UFCG-HP
# Lab3, exercicio 5
#
# Implemente um script R que permite gerar um conjunto de dados que seguem uma distribuição
# normal com uma média e um desvio padrão recebidos como parâmetro. O script deve converter
# os dados normais em lognormais e gerar as FDPs de ambos os dados em um único gráfico. As 
# FDPs devem ser devidamente identificadas e salvas em um único arquivo em formato *.png.

sampleNormal <- rnorm(10000, mean = 0, sd = 1)

sampleLogNormal <- exp(sampleNormal)

png("questao4-FDP.png")
plot(density(sampleNormal),  las = 1, main = "Normal vs Lognormal", xlab = "x", ylab = "Densidade", col = "blue", ylim=c(0,0.8), xlim=c(-3,30))
lines(density(sampleLogNormal), col = "red")
legend("topright", c("Normal","logNormal"), fill=c("blue","red"))
dev.off()
