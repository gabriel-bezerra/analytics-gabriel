#carregando dados
en <- read.csv('en.csv')
#randomizando os dados
en <- en[sample(1:nrow(en), length(1:nrow(en))), 1:ncol(en)]
#definindo quais as colunas contém dados
enValues <- en[, 1:100]
#definindo quais as colunas que contém os rótulos
enTargets <- en[, 101]
#criando saídas no formato binário para cada rótulo encontrado
enDecTargets <- decodeClassLabels(enTargets)
#dividindo os conjuntos entre treinamento e teste. Ratio é a proporção do conjunto destinado a teste. Serão criadas subvariáveis para en: en$inputsTrain, en$targetsTrain, en$inputsTest e en$targetsTest. 
en <- splitForTrainingAndTest(enValues, enDecTargets, ratio = 0.25)
#normalizando conjuntos de treinamento e teste
en <- normTrainingAndTestSet(en)
#treinando utilizando mlp
model <- mlp(en$inputsTrain, en$targetsTrain, size = 10,learnFuncParams = 0.1, maxit = 200, inputsTest = en$inputsTest,targetsTest = en$targetsTest)
#realizando predições com o modelo treinado tendo como dados de entrada o conjunto de teste
predictions <- predict(model, en$inputsTest)
#plotando gráfico da evolução do treinamento (a linha vermelha diz respeito ao conjunto de teste)
plotIterativeError(model)
#plotando erro da regressão
plotRegressionError(predictions[, 2], en$targetsTest[, 2], pch = 3)
#plotando ROC do treinamento
plotROC(fitted.values(model)[, 2], en$targetsTrain[, 2])
#plotando ROC para o conjunto de teste
plotROC(predictions[, 2], en$targetsTest[, 2])
#escrevendo no console matriz de confusão do conjunto de treinamento
confusionMatrix(en$targetsTrain, fitted.values(model))
#matriz de confusão do conjunto de teste
confusionMatrix(en$targetsTest, predictions)